<?php
namespace App\Http\Controllers\ERP;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Sale;
use App\Models\WorkOrder;
class DashboardController extends Controller
{
    public function index()
    {
        return view(
            'erp.dashboard',
            [
                'products' =>
                    Product::count(),
                'sales' =>
                    Sale::count(),
                'workOrders' =>
                    WorkOrder::count()
            ]
        );
    }
}
