<?php
namespace App\Http\Controllers\ERP;
use App\Http\Controllers\Controller;
use App\Models\CashTransaction;
class CashflowController extends Controller
{
    public function index()
    {
        return response()->json(
            CashTransaction::orderBy(
                'trx_date',
                'desc'
            )->get()
        );
    }
}
