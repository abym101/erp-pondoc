<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void
    {
        Schema::create('purchases', function (Blueprint $table) {
            $table->id();
            $table->foreignId(
                'supplier_id'
            );
            $table->string(
                'invoice_no'
            );
            $table->decimal(
                'grand_total',
                15,
                2
            )->default(0);
            $table->string(
                'payment_status'
            )->default('UNPAID');
            $table->timestamps();
        });
    }
    public function down(): void
    {
        Schema::dropIfExists(
            'purchases'
        );
    }
};
