<?php
namespace App\Http\Controllers\ERP;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\WorkOrder;
use Illuminate\Support\Facades\DB;
class KpiController extends Controller
{
    public function index()
    {
        return response()->json([
            'products' =>
                Product::count(),
            'stock_items' =>
                Product::sum('stock'),
            'sales_count' =>
                Sale::count(),
            'sales_total' =>
                Sale::sum('grand_total'),
            'work_orders' =>
                WorkOrder::count(),
            'work_order_total' =>
                WorkOrder::sum('total'),
            'today_sales' =>
                Sale::whereDate(
                    'created_at',
                    today()
                )->sum('grand_total'),
            'today_work_orders' =>
                WorkOrder::whereDate(
                    'created_at',
                    today()
                )->count(),
            'low_stock' =>
                Product::where(
                    'stock',
                    '<=',
                    10
                )
                ->orderBy('stock')
                ->get(),
            'top_products' =>
                SaleItem::select(
                    'product_id',
                    DB::raw(
                        'SUM(qty) total_qty'
                    )
                )
                ->with('product')
                ->groupBy(
                    'product_id'
                )
                ->orderByDesc(
                    'total_qty'
                )
                ->limit(10)
                ->get()
        ]);
    }
}
