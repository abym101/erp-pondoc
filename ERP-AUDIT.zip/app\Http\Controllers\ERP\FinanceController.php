<?php
namespace App\Http\Controllers\ERP;
use App\Http\Controllers\Controller;
use App\Models\CashTransaction;
class FinanceController extends Controller
{
    public function index()
    {
        $income =
            CashTransaction::where(
                'type',
                'IN'
            )->sum('amount');
        $expense =
            CashTransaction::where(
                'type',
                'OUT'
            )->sum('amount');
        return response()->json([
            'cash_in' =>
                $income,
            'cash_out' =>
                $expense,
            'balance' =>
                $income - $expense,
            'transactions' =>
                CashTransaction::latest()
                ->limit(20)
                ->get()
        ]);
    }
}
