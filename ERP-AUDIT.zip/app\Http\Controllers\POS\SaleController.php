<?php
namespace App\Http\Controllers\POS;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Customer;
use App\Models\Sale;
use App\Models\SaleItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class SaleController extends Controller
{
    public function index()
    {
        return view('sales.index',[
            'products'=>Product::orderBy('name')->get(),
            'customers'=>Customer::orderBy('name')->get(),
            'sales'=>Sale::latest()->get()
        ]);
    }
    public function store(Request $request)
    {
        DB::beginTransaction();
        try {
            $product = Product::findOrFail(
                $request->product_id
            );
            $qty = (float)$request->qty;
            $subtotal =
                $qty *
                $product->selling_price;
            $sale = Sale::create([
                'invoice_no' =>
                    'INV-'.date('YmdHis'),
                'customer_id' =>
                    $request->customer_id,
                'grand_total' =>
                    $subtotal
            ]);
            SaleItem::create([
                'sale_id' =>
                    $sale->id,
                'product_id' =>
                    $product->id,
                'qty' =>
                    $qty,
                'price' =>
                    $product->selling_price,
                'subtotal' =>
                    $subtotal
            ]);
            $product->stock =
                $product->stock - $qty;
            $product->save();
            DB::commit();
            return redirect('/erp/sales');
        } catch(\Throwable $e){
            DB::rollBack();
            return $e->getMessage();
        }
    }
}
