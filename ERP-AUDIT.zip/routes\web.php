<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ERP\DashboardController;
use App\Http\Controllers\ERP\ReportController;
use App\Http\Controllers\ERP\DailyReportController;
use App\Http\Controllers\ERP\StockReportController;
use App\Http\Controllers\Inventory\ProductController;
use App\Http\Controllers\Inventory\CategoryController;
use App\Http\Controllers\Inventory\PurchaseController;
use App\Http\Controllers\Inventory\SupplierController;
use App\Http\Controllers\Workshop\CustomerController;
use App\Http\Controllers\Workshop\VehicleController;
use App\Http\Controllers\Workshop\WorkOrderController;
use App\Http\Controllers\POS\SaleController;
Route::get('/', fn () => redirect('/erp'));
Route::get(
    '/erp',
    [DashboardController::class,'index']
);
Route::resource(
    '/erp/products',
    ProductController::class
);
Route::resource(
    '/erp/categories',
    CategoryController::class
);
Route::resource(
    '/erp/customers',
    CustomerController::class
);
Route::resource(
    '/erp/vehicles',
    VehicleController::class
);
Route::resource(
    '/erp/work-orders',
    WorkOrderController::class
);
Route::resource(
    '/erp/sales',
    SaleController::class
);
Route::prefix('erp/reports')->group(function () {
    Route::get(
        '/dashboard',
        [ReportController::class,'dashboard']
    );
    Route::get(
        '/sales',
        [ReportController::class,'sales']
    );
    Route::get(
        '/work-orders',
        [ReportController::class,'workOrders']
    );
    Route::get(
        '/stock',
        [ReportController::class,'stock']
    );
    Route::get(
        '/daily',
        [DailyReportController::class,'index']
    );
});
use App\Http\Controllers\ERP\InvoiceController;
Route::get(
    '/erp/invoice/{id}',
    [InvoiceController::class,'show']
);
use App\Http\Controllers\ERP\VehicleHistoryController;
Route::get(
'/erp/history/vehicle/{id}',
[VehicleHistoryController::class,'show']
);
use App\Http\Controllers\ERP\KpiController;
Route::get(
'/erp/kpi',
[KpiController::class,'index']
);
Route::resource(
'/erp/purchases',
PurchaseController::class
);
use App\Http\Controllers\Workshop\WorkOrderItemController;
Route::post(
'/erp/work-order-items',
[WorkOrderItemController::class,'store']
);
use App\Http\Controllers\Workshop\WorkOrderServiceController;
Route::post(
'/erp/work-order-services',
[WorkOrderServiceController::class,'store']
);
use App\Http\Controllers\ERP\WorkshopKpiController;
Route::get(
'/erp/workshop-kpi',
[WorkshopKpiController::class,'index']
);
use App\Http\Controllers\ERP\FinanceController;
Route::get(
'/erp/finance',
[FinanceController::class,'index']
);
use App\Http\Controllers\ERP\ProfitLossController;
Route::get(
'/erp/profit-loss',
[ProfitLossController::class,'index']
);
use App\Http\Controllers\ERP\CashflowController;
Route::get(
'/erp/cashflow',
[CashflowController::class,'index']
);
use App\Http\Controllers\ERP\DashboardUiController;
Route::get(
'/erp2',
[DashboardUiController::class,'index']
);
Route::get('/erp/suppliers',[SupplierController::class,'index']);
Route::post('/erp/suppliers',[SupplierController::class,'store']);
Route::get('/erp/purchases',[PurchaseController::class,'index']);
Route::post('/erp/purchases',[PurchaseController::class,'store']);
