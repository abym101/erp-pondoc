<?php
namespace App\Http\Controllers\ERP;
use App\Http\Controllers\Controller;
use App\Models\Product;
class StockReportController extends Controller
{
    public function index()
    {
        return Product::select(
            'id',
            'sku',
            'name',
            'stock',
            'purchase_price',
            'selling_price'
        )
        ->orderBy('name')
        ->get()
        ->map(function ($p) {
            return [
                'id' => $p->id,
                'sku' => $p->sku,
                'name' => $p->name,
                'stock' => $p->stock,
                'purchase_price' =>
                    $p->purchase_price,
                'selling_price' =>
                    $p->selling_price,
                'stock_value' =>
                    $p->stock *
                    $p->purchase_price
            ];
        });
    }
}
