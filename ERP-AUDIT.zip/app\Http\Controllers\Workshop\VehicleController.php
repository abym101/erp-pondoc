<?php
namespace App\Http\Controllers\Workshop;
use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Vehicle;
use Illuminate\Http\Request;
class VehicleController extends Controller
{
    public function index()
    {
        return view(
            'vehicles.index',
            [
                'customers' =>
                    Customer::orderBy('name')->get(),
                'vehicles' =>
                    Vehicle::with('customer')
                    ->orderByDesc('id')
                    ->get()
            ]
        );
    }
    public function store(Request $request)
    {
        Vehicle::create([
            'customer_id' =>
                $request->customer_id,
            'plate_number' =>
                $request->plate_number,
            'brand' =>
                $request->brand,
            'model' =>
                $request->model
        ]);
        return redirect(
            '/erp/vehicles'
        );
    }
}
