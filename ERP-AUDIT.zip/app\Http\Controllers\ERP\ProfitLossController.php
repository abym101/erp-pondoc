<?php
namespace App\Http\Controllers\ERP;
use App\Http\Controllers\Controller;
use App\Models\CashTransaction;
class ProfitLossController extends Controller
{
    public function index()
    {
        $income =
            CashTransaction::where(
                'type',
                'IN'
            )->sum('amount');
        $expense =
            CashTransaction::where(
                'type',
                'OUT'
            )->sum('amount');
        return response()->json([
            'revenue' =>
                $income,
            'expense' =>
                $expense,
            'net_profit' =>
                $income - $expense
        ]);
    }
}
