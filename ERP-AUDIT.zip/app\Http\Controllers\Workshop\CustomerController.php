<?php
namespace App\Http\Controllers\Workshop;
use App\Http\Controllers\Controller;
use App\Models\Customer;
use Illuminate\Http\Request;
class CustomerController extends Controller
{
    public function index()
    {
        return view(
            'customers.index',
            [
                'customers' =>
                    Customer::orderBy('name')
                    ->get()
            ]
        );
    }
    public function store(Request $request)
    {
        Customer::create([
            'name'    => $request->name,
            'phone'   => $request->phone,
            'address' => $request->address
        ]);
        return redirect(
            '/erp/customers'
        );
    }
}
