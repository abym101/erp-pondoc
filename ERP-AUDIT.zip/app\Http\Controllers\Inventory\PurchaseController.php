<?php
namespace App\Http\Controllers\Inventory;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\PurchaseItem;
use App\Models\StockMovement;
use App\Models\Supplier;
use Illuminate\Support\Facades\DB;
class PurchaseController extends Controller
{
    public function index()
    {
        return Purchase::latest()->get();
    }
    public function store()
    {
        DB::beginTransaction();
        try {
            $supplier =
                Supplier::first();
            $product =
                Product::first();
            $qty = 10;
            $purchase =
                Purchase::create([
                    'supplier_id' =>
                        $supplier->id,
                    'invoice_no' =>
                        'PO-'.date('YmdHis'),
                    'grand_total' =>
                        $product->purchase_price * $qty,
                    'payment_status' =>
                        'UNPAID'
                ]);
            PurchaseItem::create([
                'purchase_id' =>
                    $purchase->id,
                'product_id' =>
                    $product->id,
                'qty' =>
                    $qty,
                'price' =>
                    $product->purchase_price,
                'subtotal' =>
                    $product->purchase_price * $qty
            ]);
            $product->stock =
                $product->stock + $qty;
            $product->save();
            StockMovement::create([
                'product_id' =>
                    $product->id,
                'type' =>
                    'IN-PO',
                'qty' =>
                    $qty
            ]);
            DB::commit();
            return $purchase;
        } catch(\Throwable $e){
            DB::rollBack();
            return $e->getMessage();
        }
    }
}
